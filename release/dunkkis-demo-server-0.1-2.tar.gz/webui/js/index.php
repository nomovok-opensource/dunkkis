<?
Header("HTTP/1.1 403 Forbidden"); 
Header("Location: about:blank"); 
?>

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

CREATE TABLE IF NOT EXISTS `alarm_actions` (
  `alarmid` int(11) NOT NULL COMMENT 'alarm.id',
  `alarmcontactsid` int(11) NOT NULL COMMENT 'alarm_contacts.id',
  `type` enum('sms','email','composite') NOT NULL,
  KEY `alarmid` (`alarmid`),
  KEY `alarmcontactsid` (`alarmcontactsid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Surveillance contact to surveillance binding.';

CREATE TABLE IF NOT EXISTS `alarm_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user id',
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `createddate` datetime NOT NULL,
  `triggercount` int(11) NOT NULL COMMENT 'Number of notifications sent',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains notification contacts for surveillances.';

CREATE TABLE IF NOT EXISTS `alarm_history` (
  `uid` int(11) NOT NULL COMMENT 'user.id',
  `alarmid` int(11) NOT NULL DEFAULT '0' COMMENT 'alarm.id',
  `alarm_name` varchar(64) NOT NULL COMMENT 'Name for surveillance.',
  `sensorid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'alarm_sensors.id',
  `sensor_name` varchar(64) NOT NULL COMMENT 'User defined name for sensor.',
  `alarmscheduleid` int(11) DEFAULT NULL COMMENT 'alarm_schedules.id',
  `schedule_name` varchar(64) NOT NULL COMMENT 'User defined name for trigger.',
  `value` float(10,4) NOT NULL COMMENT 'Value of sensor at time of event.',
  `logtime` datetime NOT NULL COMMENT 'Time of event.',
  PRIMARY KEY (`alarmid`,`sensorid`,`logtime`),
  KEY `uid` (`uid`),
  KEY `alarmid` (`alarmid`),
  KEY `sensorid` (`sensorid`),
  KEY `alarmscheduleid` (`alarmscheduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains history for surveillances.';

CREATE TABLE IF NOT EXISTS `alarm_profiles` (
  `alarmid` int(11) NOT NULL COMMENT 'alarm.id',
  `profileid` int(11) unsigned NOT NULL COMMENT 'profile.id',
  `enabled` tinyint(1) NOT NULL,
  KEY `alarmid` (`alarmid`),
  KEY `profileid` (`profileid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Unused. Saved for compatibility.';

CREATE TABLE IF NOT EXISTS `alarm_queue` (
  `mac` varchar(48) NOT NULL,
  `value` float(10,4) NOT NULL,
  `type` varchar(16) NOT NULL,
  `sensorid` varchar(16) NOT NULL,
  `deviceid` varchar(16) NOT NULL,
  `time` datetime NOT NULL,
  `logtime` datetime DEFAULT NULL,
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains raw surveillance data in notification queue.';

CREATE TABLE IF NOT EXISTS `alarm_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user.id',
  `name` varchar(64) NOT NULL,
  `value_min` float(10,4) NOT NULL,
  `value_max` float(10,4) NOT NULL,
  `value_within` tinyint(1) NOT NULL,
  `always` tinyint(1) NOT NULL COMMENT '1 = active always, 0 = active at specified times',
  `period` tinyint(1) NOT NULL COMMENT '1 = active all year, 0 = active from start date to end date',
  `startdate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `months` tinyint(1) NOT NULL,
  `jan` tinyint(1) NOT NULL,
  `feb` tinyint(1) NOT NULL,
  `mar` tinyint(1) NOT NULL,
  `apr` tinyint(1) NOT NULL,
  `may` tinyint(1) NOT NULL,
  `jun` tinyint(1) NOT NULL,
  `jul` tinyint(1) NOT NULL,
  `aug` tinyint(1) NOT NULL,
  `sep` tinyint(1) NOT NULL,
  `oct` tinyint(1) NOT NULL,
  `nov` tinyint(1) NOT NULL,
  `dec` tinyint(1) NOT NULL,
  `days` tinyint(1) NOT NULL COMMENT '1 = on all, 0 = on selected',
  `sun` tinyint(1) NOT NULL,
  `mon` tinyint(1) NOT NULL,
  `tue` tinyint(1) NOT NULL,
  `wed` tinyint(1) NOT NULL,
  `thu` tinyint(1) NOT NULL,
  `fri` tinyint(1) NOT NULL,
  `sat` tinyint(1) NOT NULL,
  `first_day` int(11) NOT NULL COMMENT 'default 1',
  `last_day` int(11) NOT NULL COMMENT 'default 31',
  `all_day` tinyint(1) NOT NULL COMMENT '1 = always, 0 = from start time to end time',
  `starttime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Contains triggers for surveillances.';

CREATE TABLE IF NOT EXISTS `alarm_sensors` (
  `alarmid` int(11) NOT NULL COMMENT 'alarm.id',
  `sensorid` int(10) unsigned NOT NULL COMMENT 'sensor.id',
  `enabled` tinyint(1) NOT NULL COMMENT 'Can sensor trigger an alarm, 1 = yes, 0 = no.',
  `auto_enable` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Is sensor disabled after triggering an alarm, 1 = yes, 0 = no.',
  KEY `alarmid` (`alarmid`),
  KEY `sensorid` (`sensorid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains sensor to surveillance bindings.';

CREATE TABLE IF NOT EXISTS `alarm_triggers` (
  `alarmid` int(11) NOT NULL,
  `alarmscheduleid` int(11) NOT NULL,
  KEY `alarmid` (`alarmid`),
  KEY `alarmscheduleid` (`alarmscheduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains trigger to surveillance bindings.';

CREATE TABLE IF NOT EXISTS `alarms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user.id',
  `name` varchar(64) NOT NULL COMMENT 'User defined name for alarm.',
  `small_message` varchar(160) NOT NULL COMMENT 'SMS message, e-mail subject.',
  `long_message` text NOT NULL COMMENT 'E-Mail message.',
  `alert` enum('none','all','email','sms','composite','email_sms','sms_composite','email_composite') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Contains surveillances.';

CREATE TABLE IF NOT EXISTS `camera` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `name` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `data` (
  `mac` varchar(48) NOT NULL,
  `value` float(10,4) NOT NULL,
  `type` varchar(16) NOT NULL,
  `sensorid` varchar(48) NOT NULL,
  `deviceid` varchar(48) NOT NULL,
  `time` datetime NOT NULL,
  `logtime` datetime DEFAULT NULL,
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains data from sensors.';

CREATE TABLE IF NOT EXISTS `device` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `devidstr` varchar(48) NOT NULL,
  `name` varchar(64) NOT NULL,
  `profileid` int(11) unsigned NOT NULL,
  `dboxid` int(10) unsigned NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `profileid` (`profileid`),
  KEY `dboxid` (`dboxid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Device to profile bindings.';

CREATE TABLE IF NOT EXISTS `dunkkisbox` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` varchar(48) NOT NULL,
  `name` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='MAC device to user bindings.';

CREATE TABLE IF NOT EXISTS `picture_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture` mediumblob NOT NULL,
  `mime_type` varchar(30) DEFAULT NULL,
  `thumbnail` blob NOT NULL,
  `sensorid` varchar(16) NOT NULL,
  `logtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Contains pictures from picture sensors.';

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `password` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Contains user profiles.' ;

CREATE TABLE IF NOT EXISTS `sensor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sensoridstr` varchar(48) NOT NULL,
  `name` varchar(64) NOT NULL,
  `devid` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `devid` (`devid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Sensor to device bindings.' ;

CREATE TABLE IF NOT EXISTS `session` (
  `profileid` int(11) unsigned NOT NULL,
  `sessionid` varchar(80) NOT NULL,
  `logindate` datetime NOT NULL,
  PRIMARY KEY (`sessionid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains remote session ids.';

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL COMMENT 'Same as email. Preserved for compatibility.',
  `password` varchar(80) NOT NULL,
  `email` varchar(64) NOT NULL,
  `createdate` date NOT NULL,
  `lastlogindate` date NOT NULL,
  `logincounts` int(10) DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  `role` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 COMMENT='Contains users.';

INSERT INTO `user` (`uid`, `name`, `password`, `email`, `createdate`, `lastlogindate`, `logincounts`, `status`, `role`) VALUES
(1, 'admin', 'cc9975c7eae78ac5642b31d96f58d73d642a4e55', 'admin@localhost', '2009-04-20', '2009-08-28', 19, 1, 1);

CREATE TABLE IF NOT EXISTS `userrequest` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL COMMENT 'Same as email. Preserved for compatibility.',
  `email` varchar(64) NOT NULL,
  `requestdate` date NOT NULL,
  `text` varchar(256) NOT NULL,
  `password` varchar(80) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Contains user account requests.';

ALTER TABLE `alarm_actions`
  ADD CONSTRAINT `alarm_actions_ibfk_1` FOREIGN KEY (`alarmid`) REFERENCES `alarms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_actions_ibfk_2` FOREIGN KEY (`alarmcontactsid`) REFERENCES `alarm_contacts` (`id`) ON DELETE CASCADE;

ALTER TABLE `alarm_contacts`
  ADD CONSTRAINT `alarm_contacts_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`) ON DELETE CASCADE;

ALTER TABLE `alarm_history`
  ADD CONSTRAINT `alarm_history_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_history_ibfk_2` FOREIGN KEY (`alarmid`) REFERENCES `alarms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_history_ibfk_3` FOREIGN KEY (`sensorid`) REFERENCES `sensor` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_history_ibfk_4` FOREIGN KEY (`alarmscheduleid`) REFERENCES `alarm_schedules` (`id`) ON DELETE CASCADE;

ALTER TABLE `alarm_profiles`
  ADD CONSTRAINT `alarm_profiles_ibfk_1` FOREIGN KEY (`alarmid`) REFERENCES `alarms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_profiles_ibfk_2` FOREIGN KEY (`profileid`) REFERENCES `profile` (`id`) ON DELETE CASCADE;

ALTER TABLE `alarm_schedules`
  ADD CONSTRAINT `alarm_schedules_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`) ON DELETE CASCADE;

ALTER TABLE `alarm_sensors`
  ADD CONSTRAINT `alarm_sensors_ibfk_1` FOREIGN KEY (`alarmid`) REFERENCES `alarms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_sensors_ibfk_2` FOREIGN KEY (`sensorid`) REFERENCES `sensor` (`id`) ON DELETE CASCADE;

ALTER TABLE `alarm_triggers`
  ADD CONSTRAINT `alarm_triggers_ibfk_1` FOREIGN KEY (`alarmid`) REFERENCES `alarms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarm_triggers_ibfk_2` FOREIGN KEY (`alarmscheduleid`) REFERENCES `alarm_schedules` (`id`) ON DELETE CASCADE;

ALTER TABLE `alarms`
  ADD CONSTRAINT `alarms_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`) ON DELETE CASCADE;

ALTER TABLE `device`
  ADD CONSTRAINT `device_ibfk_1` FOREIGN KEY (`dboxid`) REFERENCES `dunkkisbox` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `device_ibfk_2` FOREIGN KEY (`profileid`) REFERENCES `profile` (`id`) ON DELETE CASCADE;

ALTER TABLE `sensor`
  ADD CONSTRAINT `sensor_ibfk_1` FOREIGN KEY (`devid`) REFERENCES `device` (`id`) ON DELETE CASCADE;
